public class CartaoDeCredito {
    private String numero;
    private float limite;
    private float saldo;
    private float cashbackRate;

    
    public CartaoDeCredito(String numero, float limiteInicial) {
        this.numero = numero;
        this.limite = limiteInicial;
        this.saldo = 0.0f;
        this.cashbackRate = 0.0f; }

   
    public CartaoDeCredito(String numero, float limiteInicial, float cashbackRate) {
        this.numero = numero;
        this.limite = limiteInicial;
        this.saldo = 0.0f;
        this.cashbackRate = cashbackRate;
    }

    public String getNumero() {
        return numero;
    }
    public void setNumero (String numero ){
        this.numero = numero;
    }

    public float getLimite() {
        return limite;
    }

    public void setLimite(float limite) {
        this.limite = limite;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public float getCashbackRate() {
        return cashbackRate;
    }

    public void setCashbackRate(float cashbackRate) {
        this.cashbackRate = cashbackRate;
    }

    
    public float consultarLimite() {
        return getLimite();
    }

    public float consultarSaldo() {
        return getSaldo();
    }

   
    public void realizarTransacao(float valor) {
        if (valor <= 0) {
            System.out.println("O valor da transação deve ser positivo.");
            return;
        }

        if (valor <= getLimite()) {
            setLimite(getLimite() - valor);
            setSaldo(getSaldo() + valor);
            System.out.println("Transação realizada com sucesso!");
        } else {
            System.out.println("Limite insuficiente para realizar a transação.");
        }
    }

    
    public void realizarTransacao(float valor, boolean comCashback) {
        if (valor <= 0) {
            System.out.println("O valor da transação deve ser positivo.");
            return;
        }

        if (valor <= getLimite()) {
            setLimite(getLimite() - valor);
            setSaldo(getSaldo() + valor);

            if (comCashback) {
                float cashback = valor * getCashbackRate();
                setLimite(getLimite() + cashback);
                System.out.printf("Transação realizada com cashback de R$%.2f!%n", cashback);
            } else {
                System.out.println("Transação realizada com sucesso!");
            }
        } else {
            System.out.println("Limite insuficiente para realizar a transação.");
        }
    }
}

    